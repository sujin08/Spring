package egovframework.guide.helloworld;

public interface HelloWorldService {
	
	public String sayHello();
}
